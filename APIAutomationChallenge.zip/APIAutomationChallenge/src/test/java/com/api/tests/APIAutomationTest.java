package com.api.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class APIAutomationTest {


    private static final String BASE_URL = "https://www.almosafer.com/en";

    @Test
    public void testGetAPI() {
        Response response = given()
                .when()
                .get(BASE_URL)
                .then()
                .statusCode(200) // Expecting a 200 OK response
                .extract()
                .response();

        //log the response
        System.out.println("GET Response: " + response.asString());
    }

    @Test
    public void testPostAPI() {

        String jsonPayload = createDynamicJsonPayload("value1", "extraValue");

        Response response = given()
                .header("Content-Type", "application/json") // Set content type to JSON
                .body(jsonPayload) // Attach dynamic JSON payload
                .when()
                .post(BASE_URL + "/flights") // Replace with your actual POST endpoint
                .then()
                .extract()
                .response();


        System.out.println("Response Status: " + response.getStatusCode());
        System.out.println("Response Location: " + response.getHeader("Location"));


        if (response.getStatusCode() == 302) {
            System.out.println("Redirected to: " + response.getHeader("Location"));

        } else {
            
            response.then().statusCode(200);
        }
    }


    private String createDynamicJsonPayload(String key1Value, String key2Value) {

        String currentDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").format(new Date());


        Map<String, Object> payloadMap = new HashMap<>();
        payloadMap.put("key1", key1Value);
        payloadMap.put("key2", currentDate);
        payloadMap.put("extraKey", key2Value);


        return new com.google.gson.Gson().toJson(payloadMap);
    }
}
